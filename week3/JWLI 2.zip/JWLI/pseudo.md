
<!-- footer section -->

</section>
            <footer class "hide">
                <section class=" clearfix">
                    <ul class="footerUl"><span class="footerTitle">Home</span> 
                        <li>About</li>
                        <li>History</li>
                        <li>Who We Are</li>
                    </ul>
                    <ul class="footerUl"><span class="footerTitle">Program</span>
                        <li>Core Values</li>
                        <li>Program Components</li>
                        <li>Host Organization</li>
                        <li>Example Events</li>
                        <li>Forum Program</li>
                    </ul>
                    <ul class="footerUl"><span class="footerTitle">JWLIA</span>
                        <li>History</li>
                        <li>Activities in Japan</li>
                        <li>Leadership</li>
                        <li>Fund</li>
                    </ul>
                    <ul class="footerUl"><span class="footerTitle">Fellows</span></ul>
                    <ul class="footerUl"><span class="footerTitle">News</span></ul>
                    <ul class="footerUl"><span class="footerTitle">Contact</span></ul>
                    <ul class="footerUl"><span class="footerTitle">日本語</span></ul>
                
</section>   
            </footer>   


<!-- CSS CODE FOR FOOTER -->

            


        